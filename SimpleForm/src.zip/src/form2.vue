<template>
    <div class="container">
      <div class="card form-card">
        <h1>Table and Form Interaction</h1>
        <form class="form-group">
          <div class="input-group" v-for="(h, index) in header" :key="index">
            <label :for="fields[h]?.label">{{ fields[h]?.label }}:</label>
  
            <!-- Dynamic input types -->
            <input
              v-if="fields[h]?.type === 'text' || fields[h]?.type === 'number'"
              :type="fields[h]?.type"
              :id="fields[h]?.label.toLowerCase()"
              v-model="newEntry[h]"
              :readonly="fields[h]?.readonly !== isFormUpdate"
              required
            />
  
            <textarea
              v-else-if="fields[h]?.type === 'textarea'"
              :id="fields[h]?.label.toLowerCase()"
              v-model="newEntry[h]"
              :readonly="fields[h]?.readonly !== isFormUpdate"
              required
            ></textarea>
  
            <div v-else-if="fields[h]?.type === 'checkbox'" class="checkbox-group">
              <label class="radio-inline">
                <input
                  type="radio"
                  value="Online"
                  v-model="newEntry[h]"
                  :disabled="fields[h]?.readonly !== isFormUpdate"
                  required
                />
                Online
              </label>
              <label class="radio-inline">
                <input
                  type="radio"
                  value="Offline"
                  v-model="newEntry[h]"
                  :disabled="fields[h]?.readonly !== isFormUpdate"
                />
                Offline
              </label>
            </div>
  
            <div
              v-else-if="fields[h].type === 'select'"
              class="select-group"
              v-show="!(fields[h]?.readonly !== isStateselect)"
              :hidden="isStateselect ^ fields[h].readonly"
            >
              <select :name="fields[h]?.name" @change="getCity">
                <option value="Select">Select {{ fields[h]?.label }}</option>
                <option v-for="s in state" :value="s.id">{{ s.name }}</option>
              </select>
            </div>
          </div>
  
          <button type="button" v-if="!isFormUpdate" class="btn btn-primary" @click="addRow">
            Add
          </button>
          <button type="button" v-if="isFormUpdate" class="btn btn-primary" @click="updateRow">
            Update
          </button>
        </form>
      </div>
  
      <!-- Table -->
      <div class="card table-card">
        <table class="styled-table">
          <thead>
            <tr>
              <th v-for="h in header" :key="h">{{ h.toUpperCase() }}</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(entry, index) in entries"
              :key="entry.id"
              @click="editRow(index)"
            >
              <td v-for="h in header" :key="h">{{ entry[h] }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, reactive, onMounted } from "vue";
  import axios from "axios";
  
  // Reactive variables
  const fields = reactive({});
  const header = ref([]);
  const entries = ref([]);
  const state = ref([]);
  
  // Form-related variables
  const newEntry = reactive({});
  const editIndex = ref(null);
  const isFormUpdate = ref(false);
  const isStateselect = false;
  
  // Utility functions
  const resetForm = () => {
    for (const key in newEntry) {
      newEntry[key] = "";
    }
    editIndex.value = null;
    isFormUpdate.value = false;
  };
  
  const handleApiError = (error, message) => {
    console.error(error);
    alert(message || "An error occurred.");
  };
  
  // API-related functions
  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:3000/api/data");
      entries.value = response.data.data;
      header.value = response.data.headers;
      Object.assign(fields, response.data.fields);
      state.value = response.data.state || []; // Assuming the state comes from the API
    } catch (error) {
      handleApiError(error, "Failed to fetch data.");
    }
  };
  
  const addRow = async () => {
    if (Object.values(newEntry).every((val) => val !== "")) {
      try {
        await axios.post("http://localhost:3000/api/submit", newEntry);
        fetchData();
        resetForm();
      } catch (error) {
        handleApiError(error, "Failed to add entry.");
      }
    } else {
      alert("Please fill out all fields.");
    }
  };
  
  const editRow = (index) => {
    editIndex.value = index;
    Object.assign(newEntry, entries.value[index]);
    isFormUpdate.value = true;
  };
  
  const updateRow = async () => {
    if (editIndex.value !== null) {
      try {
        await axios.put(`http://localhost:3000/api/updateStatus/${newEntry.id}`, newEntry);
        fetchData();
        resetForm();
      } catch (error) {
        handleApiError(error, "Failed to update entry.");
      }
    }
  };
  
  const getCity = () => {
    console.log("City selected."); // Placeholder for the city selection logic
  };
  
  // Fetch data when component is mounted
  onMounted(() => {
    fetchData();
  });
  </script>
 