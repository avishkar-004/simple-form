<template>
    <table class="styled-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Number</th>
          <th>Description</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(entry, index) in entries"
          :key="entry.id"
          @click="$emit('edit-row', index)"
        >
          <td>{{ entry.name }}</td>
          <td>{{ entry.number }}</td>
          <td>{{ entry.description }}</td>
          <td
            class="status-cell"
            :class="{ online: entry.status === 'Online', offline: entry.status === 'Offline' }"
          >
            {{ entry.status }}
          </td>
        </tr>
      </tbody>
    </table>
  </template>
  
  <script>
  export default {
    props: {
      entries: {
        type: Array,
        required: true,
      },
    },
  };
  </script>
  