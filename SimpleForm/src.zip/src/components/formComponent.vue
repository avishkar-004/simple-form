<template>
  <form class="form-group">
    <div class="input-group" v-for="(field, index) in header" :key="index">
      <label :for="field.label.toLowerCase()">{{ field.label }}:</label>

      <!-- Dynamic input types -->
      <input v-if="field.type === 'text' || field.type === 'number'" :type="field.type" :id="field.label.toLowerCase()"
        v-model="newEntry[field.label.toLowerCase()]" :readonly="field.readonly || isFormUpdate" required />
      <textarea v-else-if="field.type === 'textarea'" :id="field.label.toLowerCase()"
        v-model="newEntry[field.label.toLowerCase()]" :readonly="field.readonly ^ isFormUpdate" required></textarea>
      <div v-else-if="field.type === 'checkbox'" class="checkbox-group">
        <label class="radio-inline">
          <input type="radio" :value="'Online'" v-model="newEntry[field.label.toLowerCase()]" required
            :disabled="field.readonly ^ isFormUpdate" />
          Online
        </label>
        <label class="radio-inline">
          <input type="radio" :value="'Offline'" v-model="newEntry[field.label.toLowerCase()]"
            :disabled="field.readonly ^ isFormUpdate" />
          Offline
        </label>
      </div>
    </div>

    <button type="button" v-if="!isFormUpdate" class="btn btn-primary" @click="$emit('addRow')" >
      Add
    </button>
    <button type="button" v-if="isFormUpdate" class="btn btn-primary" @click="$emit('updateRow')">
      Update
    </button>
  </form>
</template>

<script>

export default {
  props: {
    newEntry: {
      type: Object,
      required: true,
    },
    isFormUpdate: {
      type: Boolean,
      required: true,
    },
    header: {
      type: Array,
      required: true
    }
  },
};



</script>