import './assets/form.css'

import { createApp } from 'vue'
import form from './form.vue'
createApp(form).mount('#app')