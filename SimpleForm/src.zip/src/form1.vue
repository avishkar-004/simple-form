<template>
    <div class="container">
        <div class="card form-card">
            <h1>Table and Form Interaction</h1>
            <formComponent :newEntry="newEntry" :isFormUpdate="isFormUpdate" :header="header" @add-row="addRow"
                @update-row="updateRow" />
        </div>
        <div class="card table-card">
            <tableComponent :entries="entries" @edit-row="editRow" />
        </div>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import axios from "axios";
import formComponent from "./components/formComponent.vue";
import tableComponent from "./components/tableComponent.vue";

var header = [];
const entries = ref([]);
const newEntry = reactive({
    id: null,
    name: "",
    number: "",
    description: "",
    status: "Offline",
});
const editIndex = ref(null);
const isFormUpdate = ref(false); // Tracks whether we're updating an existing entry

const fetchData = async () => {
    try {
        const response = await axios.get("http://localhost:3000/api/data");
        entries.value = response.data.data;

    } catch (error) {
        alert("Failed to fetch data. Please try again.");
    }
};

const getHeader = async () => {
    try {
        const response = await axios.get("http://localhost:3000/api/headers");
        header = response.data.headers;
        console.log(response.data.headers);
    } catch (error) {
        alert("Failed to fetch headers. Please try again." + error);
    }
};

const resetForm = () => {
    Object.assign(newEntry, { id: null, name: "", number: "", description: "", status: "Offline" });
    editIndex.value = null;
    isFormUpdate.value = false;
};

const addRow = async () => {
    if (newEntry.name && newEntry.number && newEntry.description) {
        try {
            const response = await axios.post("http://localhost:3000/api/submit", newEntry);
            entries.value.push(response.data.data);
            resetForm();
        } catch (error) {
            alert("Failed to add entry. Please try again.");
        }
    } else {
        alert("Please fill out all fields.");
    }
};

const editRow = (index) => {
    editIndex.value = index;
    Object.assign(newEntry, entries.value[index]);
    isFormUpdate.value = true;
};

const updateRow = async () => {
    if (editIndex.value !== null) {
        try {
            await axios.put(`http://localhost:3000/api/updateStatus/${newEntry.id}`, newEntry);
            entries.value[editIndex.value] = { ...newEntry };
            resetForm();
        } catch (error) {
            alert("Failed to update entry. Please try again.");
        }
    }
};

// Ensure both `fetchData` and `getHeader` run on mounted
onMounted(() => {
    fetchData();
    getHeader();
});
</script>
