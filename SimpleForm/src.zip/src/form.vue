<template>
  <div class="container">
    <div class="card form-card">
      <h1>Table and Form Interaction</h1>
      <form class="form-group">
        <div class="input-group" v-for="(h, index) in header" :key="index">
          <label :for="fields[h]?.label">{{ fields[h]?.label }}:</label>

          <!-- Dynamic input types -->
          <input
            v-if="fields[h]?.type === 'text' || fields[h]?.type === 'number'"
            :type="fields[h]?.type"
            :id="fields[h]?.label.toLowerCase()"
            v-model="newEntry[h]"
            :readonly="fields[h]?.readonly && !isFormUpdate"
            required
          />

          <textarea
            v-else-if="fields[h]?.type === 'textarea'"
            :id="fields[h]?.label.toLowerCase()"
            v-model="newEntry[h]"
            :readonly="fields[h]?.readonly && !isFormUpdate"
            required
          ></textarea>

          <div v-else-if="fields[h]?.type === 'checkbox'" class="checkbox-group">
            <label class="radio-inline">
              <input
                type="radio"
                value="Online"
                v-model="newEntry[h]"
                :disabled="fields[h]?.readonly && !isFormUpdate"
                required
              />
              Online
            </label>
            <label class="radio-inline">
              <input
                type="radio"
                value="Offline"
                v-model="newEntry[h]"
                :disabled="fields[h]?.readonly && !isFormUpdate"
              />
              Offline
            </label>
          </div>

          <div v-else-if="fields[h]?.type === 'select'" class="select-group">
            <select :name="fields[h]?.name" v-model="newEntry[h]">
              <option value="" disabled>Select {{ fields[h]?.label }}</option>
              <option v-for="s in state" :key="s.id" :value="s.name">{{ s.name }}</option>
            </select>
          </div>
        </div>

        <button type="button" v-if="!isFormUpdate" class="btn btn-primary" @click="addRow">
          Add
        </button>
        <button type="button" v-if="isFormUpdate" class="btn btn-primary" @click="updateRow">
          Update
        </button>
      </form>
    </div>

    <!-- Table -->
    <div class="card table-card">
      <table class="styled-table">
        <thead>
          <tr>
            <th v-for="h in header" :key="h">{{ h.toUpperCase() }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(entry, index) in entries" :key="entry.id" @click="editRow(index)">
            <td v-for="h in header" :key="h">{{ entry[h] }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      // Reactive variables
      fields: {},
      header: [],
      entries: [],
      state: [],

      // Form-related variables
      newEntry: {},
      editIndex: null,
      isFormUpdate: false,
    };
  },
  methods: {
    // Utility functions
    resetForm() {
      for (const key in this.newEntry) {
        this.newEntry[key] = "";
      }
      this.editIndex = null;
      this.isFormUpdate = false;
    },

    handleApiError(error, message) {
      console.error(error);
      alert(message || "An error occurred.");
    },

    // API-related functions
    async fetchData() {
      try {
        console.log("hi")
        const response = await axios.get("http://localhost:3000/api/data");        
        this.entries = response.data.data;
        this.header = response.data.headers;
        Object.assign(this.fields, response.data.fields);
        this.state = response.data.state || []; // Assuming the state comes from the API
      } catch (error) {
        this.handleApiError(error, "Failed to fetch data.");
      }
      

    },

    async addRow() {
      if (Object.values(this.newEntry).every((val) => val !== "")) {
        try {
          await axios.post("http://localhost:3000/api/submit", this.newEntry);
          this.fetchData();
          this.resetForm();
        } catch (error) {
          this.handleApiError(error, "Failed to add entry.");
        }
      } else {
        alert("Please fill out all fields.");
      }
    },

    editRow(index) {
      this.editIndex = index;
      Object.assign(this.newEntry, this.entries[index]);
      this.isFormUpdate = true;
    },

    async updateRow() {
      if (this.editIndex !== null) {
        try {
          await axios.put(
            `http://localhost:3000/api/updateStatus/${this.newEntry.id}`,
            this.newEntry
          );
          this.fetchData();
          this.resetForm();
        } catch (error) {
          this.handleApiError(error, "Failed to update entry.");
        }
      }
    },
  },
  mounted() {
    this.fetchData();
  },
};
</script>